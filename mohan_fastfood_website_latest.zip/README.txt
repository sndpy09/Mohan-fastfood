MOHAN FASTFOOD CORNER WEBSITE
Open index.html in a browser to preview.
For live publishing, upload index.html and the assets folder to a web-hosting service.
Note: This package contains the front-end demo. Real payment gateway, database-backed admin panel,
WhatsApp/order backend and secure authentication require server-side setup.
