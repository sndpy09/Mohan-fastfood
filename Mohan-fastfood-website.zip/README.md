# Mohan Fastfood Corner
Static website for GitHub Pages.

Upload `index.html`, `style.css`, `script.js` and the `assets` folder to the repository root. GitHub Pages should use `main` and `/ (root)`.

WhatsApp ordering is enabled. A real online payment gateway is not included; it requires a merchant/payment provider integration.